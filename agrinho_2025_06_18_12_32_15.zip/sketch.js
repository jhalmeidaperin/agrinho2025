let lixos = [];
let lixeiras = [];
let lixoSelecionado = null;
let pontuacao = 0;
let tempoNovoLixo = 0;

function setup() {
  createCanvas(800, 600);
  textSize(20);

  // Criar lixeiras
  lixeiras.push(new Lixeira(150, 500, "papel", color(100, 149, 237)));
  lixeiras.push(new Lixeira(350, 500, "organico", color(139, 69, 19)));
  lixeiras.push(new Lixeira(550, 500, "plastico", color(255, 165, 0)));

  // Criar lixos iniciais
  for (let i = 0; i < 3; i++) {
    lixos.push(gerarLixoAleatorio());
  }
}

function draw() {
  background(220);

  // Mostrar lixeiras
  for (let lixeira of lixeiras) {
    lixeira.mostrar();
  }

  // Mostrar lixos
  for (let lixo of lixos) {
    lixo.mostrar();
  }

  // Exibir pontuação
  fill(0);
  text("Pontuação: " + pontuacao, 10, 30);

  // Gerar novo lixo a cada 2 segundos
  if (millis() > tempoNovoLixo) {
    lixos.push(gerarLixoAleatorio());
    tempoNovoLixo = millis() + 2000;
  }
}

function mousePressed() {
  for (let lixo of lixos) {
    if (lixo.estaSobre(mouseX, mouseY)) {
      lixoSelecionado = lixo;
      break;
    }
  }
}

function mouseDragged() {
  if (lixoSelecionado) {
    lixoSelecionado.x = mouseX;
    lixoSelecionado.y = mouseY;
  }
}

function mouseReleased() {
  if (lixoSelecionado) {
    for (let lixeira of lixeiras) {
      if (lixeira.estaSobre(lixoSelecionado.x, lixoSelecionado.y)) {
        if (lixeira.tipo === lixoSelecionado.tipo) {
          pontuacao += 10;
          lixos.splice(lixos.indexOf(lixoSelecionado), 1);
        } else {
          pontuacao -= 5;
        }
        break;
      }
    }
    lixoSelecionado = null;
  }
}

// Classe para lixos
class Lixo {
  constructor(tipo, x, y) {
    this.tipo = tipo;
    this.x = x;
    this.y = y;
    this.tamanho = 40;
  }

  mostrar() {
    fill(180);
    rect(this.x, this.y, this.tamanho, this.tamanho);
    fill(0);
    textAlign(CENTER, CENTER);
    text(this.tipo, this.x + this.tamanho / 2, this.y + this.tamanho / 2);
  }

  estaSobre(mx, my) {
    return (
      mx > this.x &&
      mx < this.x + this.tamanho &&
      my > this.y &&
      my < this.y + this.tamanho
    );
  }
}

// Classe para lixeiras
class Lixeira {
  constructor(x, y, tipo, cor) {
    this.x = x;
    this.y = y;
    this.tipo = tipo;
    this.cor = cor;
    this.largura = 100;
    this.altura = 80;
  }

  mostrar() {
    fill(this.cor);
    rect(this.x, this.y, this.largura, this.altura);
    fill(255);
    textAlign(CENTER, CENTER);
    text(this.tipo, this.x + this.largura / 2, this.y + this.altura / 2);
  }

  estaSobre(lixoX, lixoY) {
    return (
      lixoX > this.x &&
      lixoX < this.x + this.largura &&
      lixoY > this.y &&
      lixoY < this.y + this.altura
    );
  }
}

// Função para gerar lixo aleatório
function gerarLixoAleatorio() {
  let tipos = ["papel", "organico", "plastico"];
  let tipo = random(tipos);
  let x = random(50, width - 90);
  let y = random(50, height / 2 - 50);
  return new Lixo(tipo, x, y);
}
